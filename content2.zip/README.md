# FPL Shirt Photo Replacer

Firefox extension which provides player image instead of shirt image for official FPL pages

![fpl img](https://github.com/user-attachments/assets/ef9510e2-ab95-467d-ab64-937fb691424e)
